<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Adldap\Adldap;

class ActiveDirectoryController extends Controller
{
    public function adLogin()
    {
        $config = array(
            'account_suffix' => "@hospital.local",

            'domain_controllers' => array("gwh-dc01.hospital.local"),

            'base_dn' => 'dc=hospital,dc=local',

            'admin_username' => 'ibox.admin',

            'admin_password' => 'ib0xGWH',
        );

        $ad = new Adldap($config);
    }
}
